@include('layout.header')
@yield('content')
@include('layout.footer')
